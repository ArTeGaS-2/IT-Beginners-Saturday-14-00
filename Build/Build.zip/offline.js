﻿{
	"version": 1744458147,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/player-sheet0.png",
		"images/player-sheet1.png",
		"images/collectable-sheet0.png",
		"images/collectable_2-sheet0.png",
		"images/obstacle-sheet0.png",
		"images/dynamicdanger-sheet0.png",
		"images/staticdanger-sheet0.png",
		"images/enemy-sheet0.png",
		"images/startbutton-sheet0.png",
		"images/reloadbutton-sheet0.png",
		"images/sprite-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}